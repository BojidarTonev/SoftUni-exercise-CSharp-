﻿using System;
using System.Collections.Generic;
using System.Text;


class Else : Food
{
    public Else(string name)
        : base(name)
    {
        base.happinessPoints = -1;
    }
}

