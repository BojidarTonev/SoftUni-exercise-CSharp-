﻿using System;
using System.Collections.Generic;
using System.Text;


class InvalidSongException : Exception
{
    public const string InvalidSongExceptionn = "Invalid song.";



}

