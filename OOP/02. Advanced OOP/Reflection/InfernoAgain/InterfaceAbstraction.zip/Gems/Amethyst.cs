﻿using System;
using System.Collections.Generic;
using System.Text;



public class Amethyst : Gem
{
    public Amethyst(GemEnums clarity)
        : base(2, 8, 4, clarity)
    {
    }
}

