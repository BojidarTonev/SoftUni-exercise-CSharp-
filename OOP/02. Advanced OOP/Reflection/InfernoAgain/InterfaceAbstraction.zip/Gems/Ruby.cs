﻿using System;
using System.Collections.Generic;
using System.Text;

public class Ruby : Gem
{
    public Ruby(GemEnums clarity)
        : base(7, 2, 5, clarity)
    {
    }
}

