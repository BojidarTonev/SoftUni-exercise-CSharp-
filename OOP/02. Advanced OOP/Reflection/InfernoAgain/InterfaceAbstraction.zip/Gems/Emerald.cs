﻿using System;
using System.Collections.Generic;
using System.Text;


public class Emerald : Gem
{
    public Emerald(GemEnums clarity)
        : base(1, 4, 9, clarity)
    {
    }
}

